{
	"head": "my/head.html",
	"body": "my/body.html"
}