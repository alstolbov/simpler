{
	"defaultContentDir": "home",
	"admin": {
		"name": "7694f4a66316e53c8cdd9d9954bd611d",
		"pass": "f1290186a5d0b1ceab27f4e77c0c5d68"
	},
  "adminDir": "16ca4dd7d66bf5be2173c9f917a38c0c",
	"defaultHeadFile": "default/head.html",
	"defaultBodyFile": "default/body.html",
	"defaultFooterFile": "default/footer.html"
}
