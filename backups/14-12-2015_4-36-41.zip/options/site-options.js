{
	"defaultContentDir": "home",
	"admin": {
		"name": "d43bf1add56efbc09b42349ba2b67e49",
		"pass": "54e21f5dc8a23aa3d057b9475d1166d8"
	},
  "adminDir": "71710e11bb4e409301934dc56d203fe3",
	"defaultHeadFile": "default/head.html",
	"defaultBodyFile": "default/body.html"
}
