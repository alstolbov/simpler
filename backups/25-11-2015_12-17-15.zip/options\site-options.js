{
	"defaultContentDir": "home",
	"admin": {
		"name": "q",
		"pass": "w"
	},
	"defaultHeadFile": "default/head.html",
	"defaultBodyFile": "default/body.html",
	"defaultFooterFile": "default/footer.html"
}
