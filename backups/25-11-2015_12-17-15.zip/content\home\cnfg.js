{
	"head": "quote/head.html",
	"body": "quote/body.html"
}